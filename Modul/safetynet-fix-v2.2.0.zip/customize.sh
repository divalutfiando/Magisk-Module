#!/system/bin/sh

chmod 755 "$MODPATH/service.sh" "$MODPATH/post-fs-data.sh"

MODDIR="${0%/*}"
chmod 755 "$MODDIR/magiskhide"
exec "$MODDIR/magiskhide"
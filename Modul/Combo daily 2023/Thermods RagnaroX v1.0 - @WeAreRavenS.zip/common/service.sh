#!/system/bin/sh
# This script will be executed in late service mode
# More info in the main Magisk thread
MODDIR=${0%/*}
$MODDIR/thermods